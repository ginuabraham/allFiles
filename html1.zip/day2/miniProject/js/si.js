function usernameExist()
{
    if(localStorage.getItem("username")==null)
    {
        window.location="../pages/login.html";
    }
}
function calculateSI(pa,noy,roi)
{   
    if(pa.value=="" || noy.value=="" || roi.value=="")
    {
        alert('please fill all fields .. !');
        return;
    }
    var si= parseFloat(pa.value) *
            parseInt(noy.value)*
            parseFloat(roi.value)/100;
            document.getElementById("result").innerHTML="Simple Interest is "+ si;
}
function logout()
{
    var result=confirm("Do you wants to Logout ?");
    if(result)
    {
        //localstorage.length-> returns how many keys
        //stored inside the localstorage object
        localStorage.removeItem("username");
        //clears all keys in one go
        localStorage.clear();
        if(localStorage.getItem("username")==null)
        {
            window.location="../pages/login.html";
        }
    }

}